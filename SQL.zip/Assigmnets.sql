-- DAY 3 Q1
select * from customers;
select customernumber, customername, state, creditlimit 
from customers where state is not null and creditlimit 
between 50000 and 100000 order by creditlimit desc;

-- DAY 3 Q2
select *from products;
select distinct productline from products where productline like "%cars%";

-- DAY 4 Q1
select * from orders;
select ordernumber, status, ifnull(comments, "-") as comments from orders 
where status = "shipped";

-- DAY 4 Q2
select * from employees;
select employeenumber, firstname, jobtitle, case
when jobtitle = "president" then "P"
when jobtitle like "%manager%" then "SM"
when jobtitle = "sales rep" then "SR"
when jobtitle like "%VP%" then "VP"
else "EMP"
end as Jobtitle_abbr from employees;

-- DAY 5 Q1
select * from payments;
select year(paymentDate), min(amount) from payments 
group by year(paymentdate) order by year(paymentDate);

-- DAY 5 Q2
select * from orders;
select year(orderdate) year, concat("Q",quarter(orderdate)) quarter,
 count(distinct customerNumber) "unique customer",
 count(*) "Total orders" 
 from orders group by year, quarter order by year,quarter;
 
 -- DAY 5 Q3
 select date_format(paymentdate,'%b') as Month, concat(format(sum(amount) / 1000,0), "K") as FormattedAmount
 from payments group by month having sum(amount) between 500000 and 1000000 order by sum(amount) desc;

-- DAY 6 Q1
create table Journey 
(Bus_ID int not null,
Bus_Name varchar (30) not null,
Source_Station varchar (30) not null,
Destination varchar (30) not null,
Email varchar (30) unique);
select* from journey;

-- Q2
create table vendor 
(Vendor_ID int primary key,
Name varchar (30) not null, 
Email varchar (30) unique,
country varchar (20) default "N/A");
select * from vendor;

-- Q3
create table movies 
(Movie_id int primary key,
Name varchar (30) not null,
Release_year varchar (30) default  "-",
cast varchar(30) not null,
gender enum ("Male", "Female"),
No_of_shows int unsigned);

-- Q4 (b)
create table suppliers
(supplier_id int primary key, 
supplier_name varchar(255), 
location varchar (255));

-- Q4 (a)
create table Product 
(product_id int primary key auto_increment, 
product_name varchar (255) not null unique,	
description varchar(255), 
supplier_id int, foreign key (supplier_id) 
references suppliers(supplier_id) 
on delete cascade on update cascade);

-- Q4 (c)
create table Stock
(id int primary key, product_id int, foreign key (product_id) references product(product_id)
on delete cascade on update cascade);

-- Q7 (1)
select employeeNumber, concat(firstname," ",lastName) as "sales person", 
count(distinct customerNumber) from employees e
join customers c on e.employeeNumber = c.salesRepEmployeeNumber group by employeeNumber 
order by count(distinct customerNumber) desc;

-- Q7 (2)
select  customers.customerNumber, customers.customerName, products.productCode, products.productName,
sum(orderdetails.quantityOrdered) as "Ordered Qty",sum(products.quantityInStock) as "Total inventory",
sum(products.quantityInStock - orderdetails.quantityOrdered) as "left qty" from customers inner join orders 
on customers.customerNumber = orders.customerNumber 
inner join orderdetails
on orders.orderNumber = orderdetails.orderNumber 
inner join products
on orderdetails.productCode = products.productCode 
group by customers.customerNumber, products.productCode 
order by customers.customerNumber asc;

-- Q7 (3)
create table  laptop (sno int, laptop_name varchar (20));
insert into laptop values (1,"Dell"), (2,"HP");
drop table colour_name;
select * from laptop;
select * from colour_name;
create table colour (sno int, colour_name varchar (20));
insert into colour values (1,"white"), (2,"Silver"), (3,"Black");
select laptop_name, colour_name from laptop cross join colour order by laptop.sno;

-- Q7 (4)
create table Project
(EmployeeID int, fullname varchar (255), gender varchar (255), managerId int);
INSERT INTO Project VALUES(1, 'Pranaya', 'Male', 3);
INSERT INTO Project VALUES(2, 'Priyanka', 'Female', 1);
INSERT INTO Project VALUES(3, 'Preety', 'Female', NULL);
INSERT INTO Project VALUES(4, 'Anurag', 'Male', 1);
INSERT INTO Project VALUES(5, 'Sambit', 'Male', 1);
INSERT INTO Project VALUES(6, 'Rajesh', 'Male', 3);
INSERT INTO Project VALUES(7, 'Hina', 'Female', 3);
select * from project;
select p.fullname as "manager Name", t.fullname "EMP Name" from project p join project t on p.employeeid = t.managerid;

-- Day 8
create table facility (facility_ID int, name varchar(100), state varchar(100), country varchar (100));
alter table facility modify facility_ID int primary key auto_increment;
alter table facility add column city varchar (255) not null after name;
desc facility;

-- Q9 
create table university 
(ID int, Name varchar (100));
INSERT INTO University
VALUES (1, "       Pune          University     "), 
               (2, "  Mumbai          University     "),
              (3, "     Delhi   University     "),
              (4, "Madras University"),
              (5, "Nagpur University");
select * from university;
update university set name = trim(both " " from regexp_replace(name, 1, ''));
select * from university;

-- Q10
select * from orders;
create view products_status as select year(o.orderdate) as year, 
concat( round(count(od.quantityordered * od.priceEach)),
'(', round ((sum(od.quantityordered * od.priceEach) / 
sum(sum(od.quantityordered * od.priceEach)) over ())*100), 
'%)' ) as "Values" from orders o join orderdetails od on o.ordernumber = od.ordernumber
group by year(o.orderdate);
select * from products_status;

-- Q11
select * from customers;
call proc_GetCustomerLevel(103);
call proc_GetCustomerLevel(112);

-- Q11 (2)
call classicmodels.Get_Country_Payments('2003', 'france');

-- Q12 (1)
with newtab as (
select year(orderdate) as year, monthname(orderdate) as Month, count(orderdate) as Total_orders
from orders group by year, month)
select year, month, total_orders as "total orders",concat(round(100 * (total_orders - LAG(total_orders) 
over (order by year)) / lag(total_orders) over (order by year)),'%' ) 
as "% YoY Change" from newtab;

-- Q12 (2)
create table emp_udf 
(Emp_ID int primary key auto_increment, Name varchar (100), DOB date);
INSERT INTO Emp_UDF(Name, DOB)
VALUES ("Piyush", "1990-03-30"), ("Aman", "1992-08-15"), 
("Meena", "1998-07-28"), ("Ketan", "2000-11-21"), ("Sanjay", "1995-05-21");
select EMP_id,name,dob,calculate_age(dob) from emp_udf;

-- Q13 (1)
select customerNumber, customerName from customers where customernumber not in (select customernumber from orders);

-- Q13(2)
select c.customerNumber, c.customerName, count(*) as "Total orders" from customers as c left join orders as o on c.customernumber = o.customernumber group by customernumber 
union
select c.customerNumber, c.customerName, count(*) as "Total orders" 
from customers as c Right join orders as o on c.customernumber = o.customernumber 
group by customernumber;

-- Q13 (3)
select orderNumber, max(quantityOrdered) as Quantityordered from orderdetails o 
where quantityOrdered <(select max(quantityOrdered) from orderdetails od
where od.ordernumber = o.ordernumber) group by orderNumber;

-- Q13 (4)
select ordernumber, count(ordernumber) as TotalProduct
from orderdetails group by ordernumber
having count(orderNumber) > 0;
select max(totalproduct) as 'MAX(Total)',
min(TotalProduct) as 'MIN(Total)'
from (select ordernumber, count(ordernumber) as TotalProduct
from orderdetails
group by ordernumber
having count(ordernumber) > 0) as Productcounts;

-- Q13 (5)
select * from products;
select productline, count(productline) Total from products 
where buyPrice > (select avg(buyPrice) from products) group by productLine;
 -- Q14
 create table Emp_EH (EmpID int Primary Key, EmpName varchar(100), EmailAddress varchar(100));
 call proc_error(3, "Ram", 5);
 
 -- Q15
 Create table Emp_BIT (Name varchar(255), Occupation varchar(255), Working_date date, Working_hours int);
 INSERT INTO Emp_BIT VALUES
('Robin', 'Scientist', '2020-10-04', 12),  
('Warner', 'Engineer', '2020-10-04', 10),  
('Peter', 'Actor', '2020-10-04', 13),  
('Marco', 'Doctor', '2020-10-04', 14),  
('Brayden', 'Teacher', '2020-10-04', 12),  
('Antonio', 'Business', '2020-10-04', 11);  
insert into emp_bit values ('john', 'Actor', '2020-05-02', -10); 
select * from emp_bit; 

